Nome: Gustavo do Prado Silva
GRR: 20203942

Supostamente tudo está funcionando, testei com todas as entradas dadas pelo Monitor (Thiago Senff) e todas retornaram corretamente com a saida esperada.
Tem alguns warnings ao compilar mas não consegui remover todos, que não atrapalham em nada a execução do código.