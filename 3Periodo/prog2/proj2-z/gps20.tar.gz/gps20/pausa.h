#include "jogo.h"

int Info(Game *jogo);

int Pausa(Game *jogo, int pontos);