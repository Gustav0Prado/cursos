#include "jogo.h"

int Inicia(Game *jogo);