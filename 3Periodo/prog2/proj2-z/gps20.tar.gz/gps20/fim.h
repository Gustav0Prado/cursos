#include "jogo.h"

int Fimpart(Game *jogo);

int Termina(Game *jogo);