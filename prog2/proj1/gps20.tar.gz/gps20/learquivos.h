/* Gustavo do Prado Siva
   GRR20203942
*/   

/*funcao para ler um arquivo de nome "nomeArq"*/
int learquivo(t_LogBike vet[], int posLog, FILE *nomeArq);