#ifndef QUEBRADOR_SENHA
#define QUEBRADOR_SENHA

int quebrador_senha_exaustivo(void);
int quebrador_senha_poda(void);


#endif
