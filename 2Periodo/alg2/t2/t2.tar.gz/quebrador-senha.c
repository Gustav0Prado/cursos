#include "biblioteca.h"
#include "quebrador-senha.h"

#define tam_senha 6
#define qtd_char 36

/*retrona se existe repeticao no vetor ou nao*/
int tem_repetido(char senha[], int tamatual){
   /*caso tenha apenas 1 elemento, nao ha repeticoes*/
   if(tamatual == 1){
      return 0;
   }
   /*para cada elemento, procura outro igual no vetor*/
   for(int i = 0; i < tamatual; i++){
      for(int j = i+1; j < tamatual; j++){
         if(senha[i] == senha[j]){
            //printf("repetidos: s[%d] = %c e s[%d] = %c\n", i, senha[i], j, senha[j]);
            return 1;
         }
      }
   }
   return 0;
}

/*retorna se a senha é valida ou nao*/
int senhavalida(char senha[], int tamatual, int tammax){
   int nums = 0;
   int letras = 0;

   /*checa apenas repeticao se ainda puder ter numeros/letras*/
   if(tamatual < tammax-1){
      if(!tem_repetido(senha, tamatual)){
         return 1;
      }
      return 0;
   }
   else if(tamatual == tammax-1){
   /*caso falte apenas um caracter e nao tenha pelo menos uma letra ou um numero, senha e invalida*/
      for(int i = 0; i < tamatual; i++){
         /*caso seja uma letra (codigos ascii)*/
         if(senha[i] <= 122 && senha[i] >= 97){
            letras++;
         }
         else if(senha[i] <= 57 && senha[i] >= 48){
            nums++;
         }
      }
      if(nums >= 1 && letras >= 1 && !tem_repetido(senha, tamatual)){
         return 1;
      }
      return 0;
   }
   /*caso tamatual = tammax*/
   else{
      for(int i = 0; i < tamatual; i++){
         /*caso seja uma letra (codigos ascii)*/
         if(senha[i] <= 122 && senha[i] >= 97){
            letras++;
         }
         else if(senha[i] <= 57 && senha[i] >= 48){
            nums++;
         }
      }
      if(nums >= 2 && letras >= 2 && !tem_repetido(senha, tamatual)){
         return 1;
      }
      return 0;
   }
}

/*funcao de backtracking com poda*/
int backtrack(char *str, char senha[], int tamstr, int tamsenha, int pos_atual){
   if(pos_atual == tamsenha){
      return login(senha);
   }
   for(int i = 0; i < tamstr; i++){
      senha[pos_atual] = str[i];
      if(senhavalida(senha, pos_atual+1, tamsenha) && backtrack(str, senha, tamstr, tamsenha, pos_atual+1)){
         return 1;
      }
   }
   return 0;

}

/*funcao de forca bruta*/
int bruteforce(char *str, char senha[], int tamstr, int tamsenha, int pos_atual){
   if(pos_atual == tamsenha){
      return login(senha);
   }
   for(int i = 0; i < tamstr; i++){
      senha[pos_atual] = str[i];
      if(bruteforce(str, senha, tamstr, tamsenha, pos_atual+1) == 1){
         return 1;
      }
   }

}

/* Retorna 1 caso tenha encontrado a senha e 0 caso contrario */
int quebrador_senha_exaustivo(){
/*coloca todas as possibilidades de caracteres em um vetor*/
   char *str = "abcdefghijklmnopqrstuvwxyz0123456789";
   char senha[tam_senha] = "";

   return bruteforce(str, senha, 36, tam_senha, 0);
}

/* Retorna 1 caso tenha encontrado a senha e 0 caso contrario */
int quebrador_senha_poda(){
   /*coloca todas as possibilidades de caracteres em um vetor*/
   char *str = "abcdefghijklmnopqrstuvwxyz0123456789";
   char senha[tam_senha] = "";

   backtrack(str, senha, 36, tam_senha, 0);
}


