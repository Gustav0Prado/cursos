int particiona(int v[], int a, int b, int x);
