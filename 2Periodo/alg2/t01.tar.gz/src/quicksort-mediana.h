int *quicksort_mediana(int v[], int a, int b);
