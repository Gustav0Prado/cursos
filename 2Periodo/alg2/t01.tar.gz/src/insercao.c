#include "biblioteca.h"

/* -------------------------------------------------------------------------- */
/* ordena v[a..b] pelo m�todo da sele��o e devolve v */

int *insercao(int v[], unsigned int a, unsigned int b) {

  return v;
}
