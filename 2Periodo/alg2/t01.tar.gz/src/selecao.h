int *selecao(int v[], unsigned int a, unsigned int b);
