extern unsigned int n_comparacoes, n_trocas;

void zera_contadores(void);
unsigned int total_trocas(void);
unsigned int total_comparacoes(void);
int compara(int a, int b);
void troca(int v[], unsigned int a, unsigned int b);
int sorteia(int min, int max);
